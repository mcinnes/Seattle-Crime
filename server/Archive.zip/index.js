var mysql = require('mysql');

var connection = mysql.createConnection({
    host     : 'com-mcinnes.ccayndqpoxrm.us-east-1.rds.amazonaws.com',
    user     : 'mcinnes',
    password : 'Znrr70xx'
});

connection.connect();

exports.handler = (event, context) => {

    connection.query("SELECT * FROM data", function(err, rows, fields) {
        console.log("rows: " + rows);
        context.succeed('Success');
    });

};